package Practice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class Camera {
    private int camid;
    private String brand;
    private String model;
    private float rentPerDay;
    private String status;

    // Getter and setter methods...
    public int getCamid() {
        return camid;
    }

    public void setCamid(int camid) {
        this.camid = camid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public float getRentPerDay() {
        return rentPerDay;
    }

    public void setRentPerDay(float rentPerDay) {
        this.rentPerDay = rentPerDay;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Constructor...
    public Camera(int camid, String brand, String model, float rentPerDay, String status) {
        this.camid = camid;
        this.brand = brand;
        this.model = model;
        this.rentPerDay = rentPerDay;
        this.status = status;
    }

    // toString method...
    @Override
    public String toString() {
        return "Camera ID: " + camid +
                ", Brand: " + brand +
                ", Model: " + model +
                ", Rent per Day: " + rentPerDay +
                ", Status: " + status;
    }
}


