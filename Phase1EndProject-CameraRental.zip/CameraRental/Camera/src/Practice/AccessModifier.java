
package Practice;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class AccessModifier {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        UserInfo user = new UserInfo();
        user.setUsername("admin");
        user.setPassword("admin@123");
        user.setWalletAmt(10000.00);

        System.out.println("+---------------------------------+");
        System.out.println("|  WELCOME TO CAMERA RENTAL APP   |");
        System.out.println("+---------------------------------+");

        System.out.print("Enter username: ");
        String inputUsername = scanner.next();
        System.out.print("Enter Password: ");
        String inputPassword = scanner.next();

        if ("admin".equals(inputUsername) && "admin@123".equals(inputPassword)) {
            CameraOperations cameraOperations = new CameraOperations();

            // Print default camera details
            cameraOperations.printDefaultCameraDetails();

            while (true) {
                System.out.println("1. My Camera");
                System.out.println("2. Rent A Camera");
                System.out.println("3. View All Cameras");
                System.out.println("4. My Wallet");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        while (true) {
                            System.out.println("1. Add Camera");
                            System.out.println("2. Remove Camera");
                            System.out.println("3. View Cameras");
                            System.out.println("4. Back to Main Menu");
                            System.out.print("Enter your choice: ");
                            int subChoice = scanner.nextInt();

                            switch (subChoice) {
                                case 1:
                                    Camera newCamera = new Camera(0, "", "", 0.0f, ""); // provide appropriate values
                                    // Set camera details using scanner input
                                    System.out.println(cameraOperations.addCameras(newCamera));
                                    break;
                                case 2:
                                    System.out.print("Enter Camera ID to Delete: ");
                                    int camIdToDelete = scanner.nextInt();
                                    System.out.println(cameraOperations.deleteCamera(camIdToDelete));
                                    break;
                                case 3:
                                    System.out.println("All Cameras:");
                                    List<Camera> allCameras = cameraOperations.showAllCameras();
                                    for (Camera camera : allCameras) {
                                        System.out.println(camera.toString());
                                    }
                                    break;
                                case 4:
                                    break;
                                default:
                                    System.out.println("Invalid choice. Please try again.");
                            }

                            if (subChoice == 4) {
                                break;
                            }
                        }
                        break;
                    case 2:
                        cameraOperations.rentACamera(1, user.getWalletAmt()); // Example camid = 1
                        break;
                    case 3:
                        System.out.println("All Cameras:");
                        List<Camera> allCameras = cameraOperations.showAllCameras();
                        for (Camera camera : allCameras) {
                            System.out.println(camera.toString());
                        }
                        break;
                    case 4:
                        user.addAmtToWallet();
                        break;
                    case 5:
                        System.out.println("Exiting the application.");
                        System.out.println("Thank you!!!!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Incorrect username/password.");
        }
    }
}
