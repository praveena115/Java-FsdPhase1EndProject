package Practice;

import java.util.Scanner;

class UserInfo {
    private String username;
    private String password;
    private double walletAmt;

    // Getter and setter methods...
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getWalletAmt() {
        return walletAmt;
    }

    public void setWalletAmt(double walletAmt) {
        this.walletAmt = walletAmt;
    }

    // AddAmtToWallet method...
    public void addAmtToWallet() {
        System.out.println("Current Wallet Balance: " + walletAmt);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Amount to Add to Wallet: ");
        double amount = scanner.nextDouble();
        walletAmt += amount;
        System.out.println("Amount Added Successfully. Total Wallet Amount: " + walletAmt);
    }
}

