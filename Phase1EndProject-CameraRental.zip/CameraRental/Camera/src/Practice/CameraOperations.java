package Practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class CameraOperations {
    private List<Camera> rentACamera = new ArrayList<>();

    // Method to print default camera details...
    public void printDefaultCameraDetails() {
        System.out.println("CAMERA ID\t\tBRAND\t\t\tMODEL\tPRICE(PER DAY)\t\tSTATUS");
        System.out.println("---------------------------------------------------------------------------------------");
        Camera[] defaultCameras = {
                new Camera(11, "\t\tSomething", "\t\tsome", 200.0f, "Rented"),
                new Camera(12, "\t\tSome", "\t\tAnother", 100.0f, "Available"),
                new Camera(14, "\t\tNIKON", "\t\tOSLR-D7500", 500.0f, "Available"),
                new Camera(15, "\t\tSony", "\t\tOSLR12", 200.0f, "Available"),
                new Camera(17, "\t\tSamsung", "\t\tSM123", 200.0f, "Available"),
                new Camera(19, "\t\tSONY", "\t\tSONY1234", 123.0f, "Available"),
                new Camera(20, "\t\tcanon", "\t\t5050", 25000.0f, "Available"),
                new Camera(21, "\t\tnikon", "\t\t2030", 500.0f, "Available")
        };

        for (Camera camera : defaultCameras) {
            System.out.printf("%-15d%-15s%-15s%-20.2f%-15s%n",
                    camera.getCamid(), camera.getBrand(), camera.getModel(),
                    camera.getRentPerDay(), camera.getStatus());
        }
        System.out.println("--------------------------------------------------------------------------------------");
    }

    public String addCameras(Camera cm) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Camera ID: ");
        int camid = scanner.nextInt();
        cm.setCamid(camid);

        scanner.nextLine(); // Consume newline left after nextInt()

        System.out.print("Enter Brand: ");
        String brand = scanner.nextLine();
        cm.setBrand(brand);

        System.out.print("Enter Model: ");
        String model = scanner.nextLine();
        cm.setModel(model);

        System.out.print("Enter Rent per Day: ");
        float rentPerDay = scanner.nextFloat();
        cm.setRentPerDay(rentPerDay);

        cm.setStatus("Available");

        rentACamera.add(cm);
        return "Camera Added Successfully.";
    }

    public List<Camera> showAllCameras() {
        Collections.sort(rentACamera, (c1, c2) -> Integer.compare(c1.getCamid(), c2.getCamid()));
        return rentACamera;
    }

    public String deleteCamera(int camid) {
        for (Camera camera : rentACamera) {
            if (camera.getCamid() == camid) {
                if ("Rented".equals(camera.getStatus())) {
                    return "Cannot delete a rented camera.";
                } else {
                    rentACamera.remove(camera);
                    return "Camera deleted successfully.";
                }
            }
        }
        return "Camera not found.";
    }

    public void rentACamera(int camid, double walletAmt) {
        System.out.println("List of Available Cameras:");
        for (Camera camera : rentACamera) {
            if ("Available".equals(camera.getStatus())) {
                System.out.println(camera.toString());
            }
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Camera ID to Rent: ");
        int selectedCamId = scanner.nextInt();

        for (Camera camera : rentACamera) {
            if (camera.getCamid() == selectedCamId && "Available".equals(camera.getStatus())) {
                if (walletAmt >= camera.getRentPerDay()) {
                    walletAmt -= camera.getRentPerDay();
                    camera.setStatus("Rented");
                    System.out.println("Camera rented successfully. Wallet Balance: " + walletAmt);
                } else {
                    System.out.println("Insufficient funds in the wallet.");
                }
                return;
            }
        }

        System.out.println("Invalid Camera ID or Camera already rented.");
    }
}


