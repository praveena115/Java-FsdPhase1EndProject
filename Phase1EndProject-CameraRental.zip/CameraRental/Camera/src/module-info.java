/**
 * 
 */
/**
 * 
 */
module Camera {
}